# ResQRoute — Emergency Route Optimization System 🚑

Run locally:
1. npm install
2. npm run dev
3. Open http://localhost:3000
